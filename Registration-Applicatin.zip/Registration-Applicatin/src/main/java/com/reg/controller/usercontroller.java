package com.reg.controller;

import java.util.logging.Logger;

import javax.servlet.http.HttpSession;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.reg.entity.UserDtls;
import com.reg.service.UserRepository;

@Controller
public class usercontroller {

	private final org.slf4j.Logger logger=LoggerFactory.getLogger(this.getClass());
	@Autowired
	private UserRepository repo;
	
	@GetMapping("/")
	public String home() {
		return "index";
	}

	
	
	
	@PostMapping("/register")
	public String register(@ModelAttribute UserDtls u ,HttpSession session,Model model) {
		System.out.println(u);
		try {
			UserDtls existinguser=repo.findByfullname(u.getFullname());
			if(existinguser !=null) {
				logger.info("User already exist...");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		repo.save(u);
		session.setAttribute("message", "User Register Successfully...");
		logger.info("User Register Successfully...");
		return "redirect:/";
		
	}
}
