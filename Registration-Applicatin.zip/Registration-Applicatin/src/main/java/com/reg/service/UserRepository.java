package com.reg.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.reg.entity.UserDtls;

public interface UserRepository extends JpaRepository<UserDtls, Integer>{
@Query
	UserDtls findByfullname(String fullname);

	

}
